﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ExcelProje.Models;
using OfficeOpenXml;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using System.Data;
using FastMember;

namespace ExcelProje.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult ExcelResult()
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            ExcelPackage package = new ExcelPackage();
            var excelBlank= package.Workbook.Worksheets.Add("Calisma1");
            //excelBlank.Cells[1, 1].Value = "Ad";

            excelBlank.Cells["A1"].LoadFromCollection(new List<Musteri>(){
                new Musteri
                {
                    Id=1,
                    Ad="ülker"
                }
            },true,OfficeOpenXml.Table.TableStyles.Light14);

            var bytes = package.GetAsByteArray();

            return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", Guid.NewGuid()+""+".xlsx");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult PdfResult()
        {
            DataTable dataTable = new DataTable();
            dataTable.Load(ObjectReader.Create(
                new List<Musteri>(){
                new Musteri
                {
                    Id=1,
                    Ad="ülker"
                }}));

            string fileName = Guid.NewGuid() + "" + ".pdf";
            string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/documents/"+fileName);
            var stream = new FileStream(path, FileMode.Create);

            Document document = new Document(PageSize.A4, 25f, 25f, 25f, 25f);
            PdfWriter.GetInstance(document, stream);

            document.Open();
            Paragraph paragraph = new Paragraph("teat afsfsfsf  dfafaf");

            document.Add(paragraph);

            //PdfPTable table = new PdfPTable(2);
            //table.AddCell("Ad");
            //table.AddCell("Soyad");

            //table.AddCell("ülker");
            //table.AddCell("Özeren");

            PdfPTable table = new PdfPTable(dataTable.Columns.Count);

            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                table.AddCell(dataTable.Columns[i].ColumnName);
            }

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                for (int j = 0; j < dataTable.Columns.Count; j++)
                {
                    table.AddCell(dataTable.Rows[i][j].ToString());
                }
            }

            document.Add(table);

            document.Close();

            return File("/documents/" + fileName, "application/pdf", fileName);
        }
    }

    class Musteri
    {
        public int Id { get; set; }
        public string Ad { get; set; }
    }
}
